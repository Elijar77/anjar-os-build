# Anjar OS 1.7 — Build, Flash & Install (honest guide)

This kit does **not** contain a ready-made ISO. No one can hand you a trustworthy
ISO from a chat sandbox (it would skip the Debian package download and signing).
What you have is a **corrected, validated build kit**. You run it once on a
Debian/Ubuntu machine and it produces your own flashable
`anjar-os-1.7-amd64.iso`.

---

## 0. What you are building (it does BOTH now)

The **default build is a single ISO that does both things**:

- **Live USB + encrypted persistence** — boot from the stick, OS runs in RAM,
  your data lives in a LUKS partition on the same stick. Nothing is written to
  the host. This is the portable / privacy mode.
- **Install-to-disk** — the live desktop has an **"Install Anjar OS to Disk"**
  icon (Calamares). It installs Anjar OS permanently onto a drive — the
  internal SSD **or another USB stick** — with optional LUKS full-disk
  encryption.

Build commands:
```bash
./build_anjar.sh                 # default: live + persistence + installer
./build_anjar.sh --no-installer  # slim: live + persistence only (smaller ISO)
```

## 1. What you need
- A PC running **Debian 13 (Trixie)** or **Ubuntu 24.04+** (a VM is fine).
- **~25 GB** free disk space and ideally **8 GB** RAM.
- A wired or solid internet connection (it downloads ~3–4 GB of packages).
- A **USB stick of 16 GB or larger** for the result.

> You cannot build this on Windows or macOS directly — `live-build` needs a
> Debian-family host. Use a quick Debian/Ubuntu VM if that's all you have.

## 2. Build
```bash
tar -xzf anjar-os-build.tar.gz
cd anjar-os-build
chmod +x build_anjar.sh
./build_anjar.sh
```
The script installs the build dependencies (asks for sudo), runs `lb config`
then `lb build`, and on success prints the ISO name and its SHA-256.
First build takes **45–90 minutes**. Later rebuilds are faster (caches).

If it fails, the most common causes are: not enough disk space, a flaky mirror
(just re-run — `lb build` resumes), or running as root directly (run as a normal
user *with* sudo, not as root).

## 3. Flash to USB
Find your USB device name carefully — **the wrong device wipes the wrong disk.**
```bash
lsblk          # identify your USB, e.g. /dev/sdb (the whole disk, not /dev/sdb1)
sudo dd if=anjar-os-1.7-amd64.iso of=/dev/sdX bs=4M status=progress oflag=sync
sync
```
Not comfortable with `dd`? Use **Balena Etcher** or GNOME **Impression** (GUI,
harder to nuke the wrong disk).

## 4. First boot
1. Boot the target PC from the USB (tap F12 / F10 / Esc at power-on for the boot
   menu; you may need to disable Secure Boot, or enable it to accept Debian's
   signed shim).
2. It auto-logs into XFCE as **anjaruser** (password `anjar`).
3. **Change the password immediately** — double-click *"Change Password (do this
   first!)"* on the Desktop.
4. Double-click **Anjar Control** and run **persist** to create your
   LUKS-encrypted persistence on the USB. Reboot, unlock, and your files in
   `~/Anjar/...` now survive reboots.
5. From Anjar Control you can then install **webapps** (Mautic/Twenty/Metabase),
   **ai** (Fooocus + Ollama), and switch **tor/vpn**. These pull from the
   internet into your encrypted persistence on demand (kept out of the read-only
   ISO on purpose).

## 4b. Install Anjar OS to a disk (optional)
1. Boot the live USB as above.
2. Double-click **"Install Anjar OS to Disk"** on the Desktop.
3. Calamares opens: pick language, keyboard, **target disk** (internal SSD or
   another USB — NOT the stick you booted from), tick **encrypt with LUKS** if
   you want full-disk encryption, create your user, and let it install.
4. Reboot, remove the live USB, and Anjar OS now boots from the installed disk.

> Test the installer in a **VM first** (e.g. VirtualBox/QEMU) before pointing it
> at real hardware. Install-to-disk is the less battle-tested of the two paths;
> see the limitations note below.

---

## 5. Honest limitations (don't get caught out)
- **Privacy ≠ Tails.** RAM/swap wipe defeats casual recovery, not a forensic or
  cold-boot adversary. For genuine anonymity, use Tails.
- **Twenty CRM** changes its Docker setup frequently. The shipped compose may
  need its env vars refreshed against Twenty's current docs the first time you
  run it. Mautic and Metabase are stable.
- **VeraCrypt** is not in Debian repos; `anjar-install-veracrypt` points you to
  the official download rather than hardcoding a version that will rot.
- **Tor** outbound is constrained by the strict firewall (DNS/80/443 + common
  Tor ports). Most relays on 443 work; some on odd ports won't. Tor Browser
  still works fine.
- **UFW default-deny-outgoing** is aggressive. DHCP is allowed so you get an IP,
  but apps using non-standard outbound ports (some email, game, or P2P traffic)
  will be blocked until you add a rule. That's intentional hardening, not a bug.

---

## 6. Changelog

### 1.2 — adds install-to-disk
- **Install-to-disk added** via Calamares as a desktop icon in the live
  session (one ISO = live+persistence AND installer). `calamares-settings-debian`
  carries the working module sequence (partitioning incl. LUKS, bootloader).
- **Recommends auto-enabled in installer mode** so Calamares gets its QML and
  helper deps and actually launches; the `--no-installer` build stays lean
  (recommends off).
- **Installer launches cleanly**: a `sudo` drop-in (SETENV + NOPASSWD for
  /usr/bin/calamares) preserves the GUI environment and avoids a password loop.
- **Bootloader binaries** (`grub-efi-amd64-bin`, `grub-pc-bin`, `os-prober`)
  baked in so Calamares can install GRUB onto the target.
- **Desktop launchers made executable** so XFCE skips the "untrusted launcher"
  prompt for a beginner.
- **Known installer caveat**: if Calamares fails to start, the cause is almost
  always a missing QML module under a lean apt setup — rebuild without
  `--no-installer` (recommends on), or add the exact `qml-module-*` package the
  error names. Test in a VM first.

### 1.1 — vs your 1.0 scaffold
1. **Build-aborting bug fixed:** `0010-create-user` added groups in one
   `usermod` under `set -e`; if the `docker` group wasn't present yet the build
   died. Now each group is created-if-missing then added, individually.
2. **Autologin login-trap fixed:** removed `passwd --expire`, which collides
   with LightDM autologin and can bounce a beginner into a greeter loop.
   Replaced with a loud first-boot notice + a one-click *Change Password*
   desktop launcher.
3. **Networking fixed:** UFW now allows DHCP egress (udp 67/68) so the machine
   can actually get an IP under default-deny-outgoing.
4. **Data-loss risk reduced:** `anjar-setup-persistence` now finds the new
   partition by its GPT label and refuses to touch your running system disk,
   instead of guessing with `lsblk | tail -1`.
5. **Honesty fixes:** README no longer claims the Chromium AppArmor profile is
   always enforced (Debian ships no base profile); sudoers per-command denials
   are labelled as speed bumps, not a boundary.
6. **Cleanup:** removed duplicate package entries (git, secure-delete,
   network-manager-gnome); bumped image name to `anjar-os-1.7-amd64`; ensured
   every hook and script is executable (live-build skips non-executable hooks).

All shell scripts pass `bash -n` / `sh -n`; all compose files parse as valid
YAML. The only thing not verifiable from a sandbox is the full `lb build` run
itself — that needs a real Debian host with network and root, which is step 2.
