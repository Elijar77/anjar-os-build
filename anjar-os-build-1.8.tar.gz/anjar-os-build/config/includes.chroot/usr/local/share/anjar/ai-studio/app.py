#!/usr/bin/env python3
# =============================================================================
#  Anjar AI Studio  —  offline one-prompt content factory at the heart of Anjar OS.
#  Type ONE prompt -> script + branded visual + voiceover + faceless video.
#  Uses only baked-in tools (espeak-ng, Pillow, ffmpeg). The local LLM (Ollama)
#  and Fooocus images are optional upgrades installed once into encrypted USB.
#  Nothing ever leaves the device.
# =============================================================================
import os
import shutil
import subprocess
import datetime
from flask import (Flask, request, jsonify, render_template_string,
                   send_from_directory)

HOME = os.path.expanduser("~")
WORK = os.path.join(HOME, "Anjar", "Campaigns")
os.makedirs(WORK, exist_ok=True)
OLLAMA_MODEL = os.environ.get("ANJAR_MODEL", "llama3.2:3b")
FOOOCUS_DIR = os.path.join(HOME, "Anjar", "AI-Models", "Fooocus")

BG = (0x2b, 0x2e, 0x39)
SURF = (0x35, 0x3a, 0x47)
INK = (0xe9, 0xec, 0xf2)
MUTE = (0x9a, 0xa3, 0xb6)
BLUE = (0xaf, 0x18, 0xa1)

FONTS_BOLD = ["/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
              "/usr/share/fonts/truetype/noto/NotoSans-Bold.ttf",
              "/usr/share/fonts/opentype/noto/NotoSans-Bold.ttf"]
FONTS_REG = ["/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
             "/usr/share/fonts/truetype/noto/NotoSans-Regular.ttf"]

app = Flask(__name__)


def have(cmd):
    return shutil.which(cmd) is not None


def tts_engine():
    return "espeak-ng" if have("espeak-ng") else ("espeak" if have("espeak") else None)


def safe(name):
    return os.path.basename(name or "")


def _stamp():
    return datetime.datetime.now().strftime("%Y%m%d-%H%M%S")


def _font(paths, size):
    try:
        from PIL import ImageFont
        for p in paths:
            if os.path.isfile(p):
                return ImageFont.truetype(p, size)
        return ImageFont.load_default()
    except Exception:
        return None


def build_prompt(kind, topic, lang):
    lng = "Polish" if lang == "pl" else "English"
    t = {
        "hook": ("Write 5 short scroll-stopping hooks (max 12 words each) for a "
                 "faceless short video about: {t}. Language: {l}. Numbered list only."),
        "caption": ("Write a social caption for a faceless post about: {t}. "
                    "Language: {l}. Punchy, value-first, one call to action. "
                    "Then 8 relevant hashtags on a new line."),
        "script": ("Write a 45-60 second faceless voiceover script about: {t}. "
                   "Language: {l}. Conversational, one idea per sentence, strong "
                   "first line, end with a call to action. Plain text only."),
        "hashtags": ("List 20 relevant non-spammy hashtags about: {t}. Language: "
                     "{l}. Space-separated, no commentary."),
        "ad": ("Write 3 ad variations for {t}. Each: a headline (max 8 words), "
               "primary text (max 30 words), and a call to action. Language: {l}."),
    }.get(kind, "{t}")
    return t.format(t=topic, l=lng)


def template_script(prompt, lang):
    p = prompt.strip().rstrip(".")
    if lang == "pl":
        return (f"Zastanawiasz sie nad tym: {p}? Oto co musisz wiedziec. "
                f"Po pierwsze, to prostsze niz myslisz. Po drugie, mozesz zaczac "
                f"juz dzis, bez kamery i bez pokazywania twarzy. Zapisz to i obserwuj, "
                f"aby dowiedziec sie wiecej.")
    return (f"Ever wondered about this: {p}? Here is what you need to know. "
            f"First, it is simpler than it looks. Second, you can start today, "
            f"with no camera and no face on screen. Save this and follow for more.")


def template_ad(product, audience, lang):
    if lang == "pl":
        return (f"Naglowek: {product} dla {audience}\n"
                f"Tekst: Oszczedzaj czas i pracuj madrzej. {product} pomaga "
                f"{audience} osiagac wiecej, prywatnie i offline.\n"
                f"CTA: Wyprobuj juz dzis.")
    return (f"Headline: {product} for {audience}\n"
            f"Primary text: Save time and work smarter. {product} helps "
            f"{audience} do more — private, offline, all in one place.\n"
            f"Call to action: Get started today.")


def render_card(headline, footer, fmt="portrait"):
    try:
        from PIL import Image, ImageDraw
    except Exception:
        return None
    import textwrap
    W, H = (1080, 1920) if fmt == "portrait" else (1080, 1080)
    img = Image.new("RGB", (W, H), BG)
    d = ImageDraw.Draw(img, "RGBA")
    for gy in range(50, H, 54):
        for gx in range(50, W, 54):
            d.ellipse([gx-1, gy-1, gx+1, gy+1], fill=(255, 255, 255, 9))
    d.rectangle([0, 0, W, 14], fill=BLUE)
    hl = (headline or "Anjar OS").strip()
    size = 96 if len(hl) < 60 else 74
    f = _font(FONTS_BOLD, size)
    wrap = textwrap.wrap(hl, width=18 if size == 96 else 24) or [hl]
    line_h = int(size * 1.18)
    total = line_h * len(wrap)
    y = (H - total) // 2 - 40
    for ln in wrap:
        bb = d.textbbox((0, 0), ln, font=f)
        d.text(((W - (bb[2]-bb[0]))/2 - bb[0], y), ln, font=f, fill=INK)
        y += line_h
    rf = _font(FONTS_REG, 34)
    fb = d.textbbox((0, 0), footer, font=rf)
    d.text(((W - (fb[2]-fb[0]))/2 - fb[0], H - 120), footer, font=rf, fill=MUTE)
    # corner logo
    d.rounded_rectangle([54, 54, 54+58, 54+58], radius=14, fill=BLUE)
    lf = _font(FONTS_BOLD, 38)
    ab = d.textbbox((0, 0), "A", font=lf)
    d.text((54+(58-(ab[2]-ab[0]))/2-ab[0], 54+(58-(ab[3]-ab[1]))/2-ab[1]), "A", font=lf, fill=(255, 255, 255))
    out = f"visual-{_stamp()}.png"
    img.save(os.path.join(WORK, out), "PNG")
    return out


def _ollama(prompt):
    out = subprocess.run(["ollama", "run", OLLAMA_MODEL, prompt],
                         capture_output=True, text=True, timeout=180)
    return (out.stdout or out.stderr).strip()


def _synth_voice(text, lang):
    eng = tts_engine()
    if not eng or not text.strip():
        return None
    voice = "pl" if lang == "pl" else "en"
    s = _stamp()
    wav = os.path.join(WORK, f"voice-{s}.wav")
    mp3 = os.path.join(WORK, f"voice-{s}.mp3")
    subprocess.run([eng, "-v", voice, "-s", "160", "-w", wav, text], check=True,
                   capture_output=True)
    if have("ffmpeg"):
        subprocess.run(["ffmpeg", "-y", "-i", wav, mp3], check=True, capture_output=True)
        os.remove(wav)
        return os.path.basename(mp3)
    return os.path.basename(wav)


def _silent(seconds):
    if not have("ffmpeg"):
        return None
    s = _stamp()
    out = os.path.join(WORK, f"silent-{s}.m4a")
    subprocess.run(["ffmpeg", "-y", "-f", "lavfi", "-i",
                    "anullsrc=channel_layout=stereo:sample_rate=44100",
                    "-t", str(seconds), "-c:a", "aac", out],
                   check=True, capture_output=True)
    return os.path.basename(out)


def _assemble(image, audio):
    img = os.path.join(WORK, safe(image))
    aud = os.path.join(WORK, safe(audio))
    if not (os.path.isfile(img) and os.path.isfile(aud) and have("ffmpeg")):
        return None
    out = os.path.join(WORK, f"video-{_stamp()}.mp4")
    subprocess.run(["ffmpeg", "-y", "-loop", "1", "-i", img, "-i", aud,
                    "-c:v", "libx264", "-tune", "stillimage", "-c:a", "aac",
                    "-b:a", "192k", "-pix_fmt", "yuv420p", "-shortest", out],
                   check=True, capture_output=True)
    return os.path.basename(out)


INDEX = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>Anjar AI Studio</title>
<style>
 :root{--bg:#2b2e39;--surface:#353a47;--surface2:#3b4150;--line:#474e60;
  --text:#e6e9ef;--muted:#9aa3b6;--accent:#af18a1;--accent2:#7e1273;}
 *{box-sizing:border-box} body{margin:0;background:var(--bg);color:var(--text);
  font-family:'Noto Sans',system-ui,sans-serif;font-size:15px;line-height:1.5}
 header{display:flex;align-items:center;gap:12px;padding:14px 20px;background:var(--surface);border-bottom:1px solid var(--line)}
 .logo{width:30px;height:30px;border-radius:8px;background:var(--accent);display:flex;align-items:center;justify-content:center;font-weight:700;color:#fff}
 h1{font-size:17px;margin:0;font-weight:600}.sub{color:var(--muted);font-size:12px}
 .lang{margin-left:auto;display:flex;gap:6px}
 .lang button{background:var(--surface2);color:var(--muted);border:1px solid var(--line);border-radius:6px;padding:5px 10px;cursor:pointer}
 .lang button.on{background:var(--accent);color:#fff;border-color:var(--accent)}
 .health{display:flex;gap:8px;flex-wrap:wrap;padding:10px 20px;font-size:12px;background:var(--surface);border-bottom:1px solid var(--line)}
 .chip{padding:3px 9px;border-radius:20px;border:1px solid var(--line)}
 .chip.ok{color:#9ee6c6;border-color:#1d9e75}.chip.no{color:#f3b0a8;border-color:#a3433a}
 nav{display:flex;gap:4px;padding:12px 20px 0;flex-wrap:wrap}
 nav button{background:transparent;color:var(--muted);border:0;border-bottom:2px solid transparent;padding:8px 12px;cursor:pointer;font-size:14px}
 nav button.on{color:var(--text);border-bottom-color:var(--accent)}
 main{padding:18px 20px;max-width:780px}.panel{display:none}.panel.on{display:block}
 label{display:block;color:var(--muted);font-size:13px;margin:12px 0 5px}
 input,select,textarea{width:100%;background:var(--surface2);color:var(--text);border:1px solid var(--line);border-radius:7px;padding:9px 11px;font:inherit}
 textarea{min-height:90px;resize:vertical}.row{display:flex;gap:10px}.row>*{flex:1}
 .btn{margin-top:14px;background:var(--accent);color:#fff;border:0;border-radius:7px;padding:11px 20px;font-size:15px;font-weight:600;cursor:pointer}
 .btn.alt{background:var(--accent2)} .hero{background:var(--surface);border:1px solid var(--line);border-radius:10px;padding:16px}
 .out{margin-top:16px;background:var(--surface);border:1px solid var(--line);border-radius:8px;padding:14px;white-space:pre-wrap;min-height:40px;color:#dfe4ee}
 .note{color:var(--muted);font-size:12px;margin-top:8px} a{color:var(--accent)}
 .step{display:flex;gap:8px;align-items:center;font-size:13px;margin:4px 0}
 .dot{width:9px;height:9px;border-radius:50%;background:#5a6072}.dot.ok{background:#1d9e75}.dot.skip{background:#a07a2a}
 .file{display:flex;justify-content:space-between;padding:8px 12px;border:1px solid var(--line);border-radius:7px;margin-top:8px;font-size:13px}
 .warn{background:#42361f;border:1px solid #7a5e26;color:#f0d79a;padding:10px 12px;border-radius:7px;font-size:13px;margin-top:10px}
</style></head><body>
<header><div class="logo">A</div>
 <div><h1>Anjar AI Studio</h1><div class="sub">Offline one-prompt content factory · model: {{model}} · 100% local</div></div>
 <div class="lang"><button id="en" class="on" onclick="setLang('en')">EN</button><button id="pl" onclick="setLang('pl')">PL</button></div>
</header>
<div class="health" id="health"><span class="chip">checking tools…</span></div>
<nav>
 <button class="on" data-t="auto" onclick="tab('auto')">Campaign · 1 prompt</button>
 <button data-t="ads" onclick="tab('ads')">Ads</button>
 <button data-t="copy" onclick="tab('copy')">Copy</button>
 <button data-t="voice" onclick="tab('voice')">Voiceover</button>
 <button data-t="video" onclick="tab('video')">Assemble</button>
 <button data-t="files" onclick="tab('files');loadFiles()">Files</button>
</nav>
<main>
 <section class="panel on" id="p-auto">
  <div class="hero">
   <label>Describe your faceless video in one line — Anjar does the rest</label>
   <textarea id="aprompt" placeholder="e.g. how UK truckers can start a faceless side hustle"></textarea>
   <div class="row">
    <div><label>Format</label><select id="afmt"><option value="portrait">Portrait (Reels/Shorts/TikTok)</option><option value="square">Square (Feed)</option></select></div>
   </div>
   <button class="btn" onclick="auto()">Create everything</button>
  </div>
  <div class="out" id="autoOut">Script, branded visual, voiceover and a finished MP4 — from one prompt.</div>
 </section>

 <section class="panel" id="p-ads">
  <label>Product / service</label><input id="adprod" placeholder="e.g. Anjar faceless content service">
  <label>Audience</label><input id="adaud" placeholder="e.g. small UK business owners">
  <div class="row"><div><label>Platform</label><select id="adplat"><option>Facebook</option><option>Google</option><option>Instagram</option></select></div></div>
  <button class="btn alt" onclick="ad()">Generate ad + creative</button>
  <div class="out" id="adOut">Ad copy variants plus a branded ad image.</div>
 </section>

 <section class="panel" id="p-copy">
  <label>What is the content about?</label><input id="topic" placeholder="e.g. how UK truckers can start a side hustle">
  <div class="row"><div><label>Type</label><select id="kind">
   <option value="hook">Video hooks</option><option value="caption" selected>Caption + hashtags</option>
   <option value="script">Voiceover script</option><option value="hashtags">Hashtags only</option></select></div></div>
  <button class="btn" onclick="gen()">Generate</button>
  <div class="out" id="copyOut">Your generated copy appears here.</div>
 </section>

 <section class="panel" id="p-voice">
  <label>Script / text to narrate</label><textarea id="vtext" placeholder="Paste or type the words…"></textarea>
  <button class="btn" onclick="tts()">Make voiceover (MP3)</button>
  <div class="out" id="voiceOut">Generated audio appears in the Files tab.</div>
 </section>

 <section class="panel" id="p-video">
  <label>Image file (in Campaigns folder)</label><input id="vimg" placeholder="e.g. visual-...png">
  <label>Voiceover file (in Campaigns folder)</label><input id="vaud" placeholder="e.g. voice-...mp3">
  <button class="btn alt" onclick="assemble()">Assemble faceless video (MP4)</button>
  <div class="out" id="videoOut">An image + a voiceover become a shareable MP4.</div>
 </section>

 <section class="panel" id="p-files"><div id="filelist" class="note">Loading…</div></section>
</main>
<script>
let LANG='en';
function setLang(l){LANG=l;document.getElementById('en').classList.toggle('on',l=='en');document.getElementById('pl').classList.toggle('on',l=='pl');}
function tab(t){document.querySelectorAll('.panel').forEach(p=>p.classList.remove('on'));document.getElementById('p-'+t).classList.add('on');
 document.querySelectorAll('nav button').forEach(b=>b.classList.toggle('on',b.dataset.t==t));}
async function health(){const h=await (await fetch('/api/health')).json();
 const lbl={ollama:'AI copy (Ollama)',espeak:'Voiceover',ffmpeg:'Video',pillow:'Visuals'};let s='';
 for(const k of ['ollama','espeak','ffmpeg','pillow']) s+='<span class="chip '+(h[k]?'ok':'no')+'">'+(h[k]?'● ':'○ ')+lbl[k]+'</span>';
 document.getElementById('health').innerHTML=s;}
function flink(f){return '<div class="file"><span>'+f+'</span><a href="/files/'+encodeURIComponent(f)+'" download>download</a></div>';}
async function auto(){const o=document.getElementById('autoOut');o.textContent='Working locally — this can take a moment…';
 const r=await fetch('/api/auto',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({prompt:aprompt.value,format:afmt.value,lang:LANG})});
 const d=await r.json();if(d.error){o.textContent=d.error;return;}
 const lab={ai:'AI-written',template:'template (install AI for better copy)',ok:'done',skip:'skipped'};
 let h='<div class="step"><span class="dot ok"></span>Script ('+lab[d.steps.script]+')</div>';
 h+='<div class="step"><span class="dot '+(d.steps.image=='ok'?'ok':'skip')+'"></span>Branded visual</div>';
 h+='<div class="step"><span class="dot '+(d.steps.voice=='ok'?'ok':'skip')+'"></span>Voiceover</div>';
 h+='<div class="step"><span class="dot '+(d.steps.video=='ok'?'ok':'skip')+'"></span>Faceless video</div>';
 h+='<div style="margin-top:10px;color:#cfd5e0">Script:</div><div style="margin-top:4px">'+(d.script||'')+'</div>';
 if(d.video)h+='<div style="margin-top:10px">'+flink(d.video)+'</div>';
 if(d.image)h+=flink(d.image); if(d.audio)h+=flink(d.audio);
 if(d.steps.voice=='skip')h+='<div class="warn">Voiceover engine not found — video uses the visual with silent audio. espeak-ng ships in the OS.</div>';
 o.innerHTML=h;}
async function ad(){const o=document.getElementById('adOut');o.textContent='Generating…';
 const r=await fetch('/api/ad',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({product:adprod.value,audience:adaud.value,platform:adplat.value,lang:LANG})});
 const d=await r.json();if(d.error){o.textContent=d.error;return;}
 let h=(d.copy||'')+'\n';if(d.image)h+='\n'+'';o.innerHTML='<div style="white-space:pre-wrap">'+(d.copy||'')+'</div>'+(d.image?flink(d.image):'');}
async function gen(){const o=document.getElementById('copyOut');o.textContent='Generating…';
 const d=await (await fetch('/api/copy',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic:topic.value,kind:kind.value,lang:LANG})})).json();
 if(d.needs_install){o.innerHTML='<div class="warn">AI copy needs the local model. Open Anjar Control → ai once to install it.</div>';return;}
 o.textContent=d.text||d.error||'No output.';}
async function tts(){const o=document.getElementById('voiceOut');o.textContent='Synthesising…';
 const d=await (await fetch('/api/tts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({text:vtext.value,lang:LANG})})).json();
 if(d.error=='no_tts'){o.innerHTML='<div class="warn">No TTS engine found.</div>';return;}o.innerHTML=d.file?('Saved: '+flink(d.file)):(d.error||'Failed.');}
async function assemble(){const o=document.getElementById('videoOut');o.textContent='Rendering…';
 const d=await (await fetch('/api/assemble',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({image:vimg.value,audio:vaud.value})})).json();
 o.innerHTML=d.file?('Done: '+flink(d.file)):(d.error||'Failed.');}
async function loadFiles(){const d=await (await fetch('/api/files')).json();const b=document.getElementById('filelist');
 b.innerHTML=d.files.length?d.files.map(flink).join(''):'<div class="note">No files yet in '+d.workspace+'</div>';}
health();
</script></body></html>"""


@app.route("/")
def index():
    return render_template_string(INDEX, model=OLLAMA_MODEL)


@app.route("/api/health")
def health():
    try:
        import PIL  # noqa
        pillow = True
    except Exception:
        pillow = False
    return jsonify(ollama=have("ollama"), fooocus=os.path.isdir(FOOOCUS_DIR),
                   espeak=tts_engine() is not None, ffmpeg=have("ffmpeg"),
                   pillow=pillow, workspace=WORK)


@app.route("/api/copy", methods=["POST"])
def copy():
    data = request.get_json(force=True, silent=True) or {}
    topic = (data.get("topic") or "").strip()
    if not topic:
        return jsonify(error="empty_topic"), 400
    if not have("ollama"):
        return jsonify(needs_install="ai")
    try:
        return jsonify(text=_ollama(build_prompt(data.get("kind", "caption"), topic, data.get("lang", "en"))))
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route("/api/tts", methods=["POST"])
def tts():
    data = request.get_json(force=True, silent=True) or {}
    text = (data.get("text") or "").strip()
    if not text:
        return jsonify(error="empty_text"), 400
    if not tts_engine():
        return jsonify(error="no_tts")
    try:
        return jsonify(file=_synth_voice(text, data.get("lang", "en")))
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route("/api/assemble", methods=["POST"])
def assemble():
    data = request.get_json(force=True, silent=True) or {}
    try:
        f = _assemble(data.get("image"), data.get("audio"))
        return jsonify(file=f) if f else (jsonify(error="missing image/audio or ffmpeg"), 400)
    except Exception as e:
        return jsonify(error=str(e)), 500


@app.route("/api/auto", methods=["POST"])
def auto():
    data = request.get_json(force=True, silent=True) or {}
    prompt = (data.get("prompt") or "").strip()
    lang = data.get("lang", "en")
    fmt = data.get("format", "portrait")
    if not prompt:
        return jsonify(error="empty_prompt"), 400
    steps = {}
    try:
        if have("ollama"):
            script = _ollama(build_prompt("script", prompt, lang)); steps["script"] = "ai"
        else:
            script = template_script(prompt, lang); steps["script"] = "template"
    except Exception:
        script = template_script(prompt, lang); steps["script"] = "template"

    headline = prompt if len(prompt) <= 80 else prompt[:77] + "…"
    image = render_card(headline, "ANJAR OS · PRIVATE · OFFLINE", fmt)
    steps["image"] = "ok" if image else "skip"

    audio = None
    try:
        audio = _synth_voice(script, lang)
    except Exception:
        audio = None
    steps["voice"] = "ok" if audio else "skip"

    if not audio:
        dur = max(5, min(60, int(len(script.split()) * 0.45)))
        audio = _silent(dur)

    video = None
    try:
        if image and audio:
            video = _assemble(image, audio)
    except Exception:
        video = None
    steps["video"] = "ok" if video else "skip"

    return jsonify(script=script, image=image,
                   audio=audio if (audio and audio.startswith("voice")) else None,
                   video=video, steps=steps)


@app.route("/api/ad", methods=["POST"])
def ad():
    data = request.get_json(force=True, silent=True) or {}
    product = (data.get("product") or "").strip()
    audience = (data.get("audience") or "everyone").strip()
    lang = data.get("lang", "en")
    if not product:
        return jsonify(error="empty_product"), 400
    try:
        if have("ollama"):
            copy = _ollama(build_prompt("ad", f"{product} (audience: {audience})", lang))
        else:
            copy = template_ad(product, audience, lang)
    except Exception:
        copy = template_ad(product, audience, lang)
    image = render_card(product, "ANJAR OS", "square")
    return jsonify(copy=copy, image=image)


@app.route("/api/files")
def files():
    items = sorted(f for f in os.listdir(WORK) if os.path.isfile(os.path.join(WORK, f)))
    return jsonify(files=items, workspace=WORK)


@app.route("/files/<path:name>")
def download(name):
    return send_from_directory(WORK, safe(name), as_attachment=True)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=8765, debug=False)
