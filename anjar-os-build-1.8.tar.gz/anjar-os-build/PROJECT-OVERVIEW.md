# Anjar OS — Project Overview

**Author:** _[your name]_ · **Student ID:** _[id]_ · **Course/Module:** _[course]_ · **Date:** _[date]_

---

## 1. Abstract

Anjar OS is a custom Debian 13 ("Trixie") live operating system, distributed as a
single bootable USB image, aimed at a non-technical user who needs a portable,
security-hardened workstation for digital marketing, faceless content creation,
and basic defensive security. The image is produced reproducibly from source
using Debian's official `live-build` toolchain. It boots entirely into RAM,
optionally merges a **LUKS-encrypted persistence** volume so the user's data
survives reboots, and can additionally **install itself to a disk** via a
graphical installer. The design deliberately separates a small, read-only,
hardened base image from heavy, stateful applications that are provisioned into
encrypted storage on demand.

## 2. Goals and design principles

1. **Portable and host-agnostic.** Boot any 64-bit PC from USB without touching
   its internal disk; leave no data behind unless the user chooses persistence.
2. **Secure by default, honest about limits.** Deny-by-default firewall, kernel
   hardening, AppArmor, locked root account, password-prompted `sudo`,
   shutdown-time memory hygiene — while being explicit that this is *not* a
   forensic-grade anonymity tool (that is Tails' job).
3. **Small read-only core, heavy apps on encrypted storage.** Multi-gigabyte,
   fast-changing tools (CRM, marketing automation, local AI models) are *not*
   baked into the image; they are installed into the user's LUKS volume on first
   use. This keeps the image ~3–4 GB and keeps the heavy stack updatable.
4. **Beginner-first UX.** Auto-login to a themed XFCE desktop, a single "Anjar
   Control" menu, and clearly labelled desktop launchers for the few actions a
   new user must take (change password, set up persistence, install to disk).
5. **Reproducible from source.** The entire OS is defined by text files in this
   repository; a single script rebuilds the identical image on any Debian host.

## 3. System architecture

```
                       ┌─────────────────────────────────────────────┐
   USB stick           │  Read-only SquashFS image (the live system)  │
 ┌───────────────┐     │  • Debian 13 base, kernel 6.x, firmware      │
 │ EFI + live    │ ──► │  • XFCE desktop (themed, auto-login)          │
 │ partitions    │     │  • Native tools: Chromium, OBS, Kdenlive,    │
 ├───────────────┤     │    GIMP/Inkscape, LibreOffice                 │
 │ LUKS          │     │  • Security: UFW, AppArmor, Tor, ClamAV,      │
 │ "persistence" │ ◄── │    KeePassXC, BleachBit, secure-delete        │
 │ (encrypted)   │     │  • Anjar AI Studio (offline copy/voiceover/video)
   │  • Docker engine + local AI runtime           │
 └───────────────┘     │  • Calamares installer (install-to-disk)      │
   user data,          └─────────────────────────────────────────────┘
   AI models,            On first use, heavy apps are provisioned into
   CRM/marketing         the encrypted persistence volume — never into
   stacks                the read-only image.
```

**Boot flow:** GRUB (UEFI or Legacy BIOS) → `live-boot` loads the SquashFS into
RAM → if a LUKS volume labelled `persistence` is present, the user is prompted to
unlock it and it is union-mounted over the live filesystem → LightDM auto-logs in
to XFCE → a one-time first-boot service prepares the user's data directories and
(if online) refreshes antivirus signatures.

## 3b. Anjar AI Studio (the AI core)

Anjar AI Studio is a local web application (served on `127.0.0.1`, opened as a
desktop app) that ties the AI tooling into one marketing workflow, entirely
offline:

- **Copy** — marketing hooks, captions, scripts, and hashtags via a local LLM
  (Ollama); EN/PL.
- **Voiceover** — text-to-speech to an audio file using an on-device engine
  (works out of the box).
- **Assemble** — combines an image and a voiceover into a shareable faceless
  video with `ffmpeg` (verified producing real H.264/AAC MP4 output).
- **Files** — a per-campaign workspace inside the encrypted volume.
- **Campaign (one prompt)** — a single prompt is expanded into a script, a
  locally-rendered branded visual, a voiceover, and an assembled faceless
  MP4, using only baked-in tools.
- **Ads** — ad-copy variants plus a branded ad creative for paid social.
- **Branding** — a custom Anjar wallpaper and themed desktop applied on
  first login give the system a consistent, professional identity.

No data leaves the device at any point; the privacy guarantee is the product's
core differentiator, not an afterthought.

## 4. Security design (and its honest boundaries)

| Control | Mechanism | Honest limitation |
|---|---|---|
| Network ingress/egress | UFW: deny inbound; egress limited to DNS, HTTP/S, NTP, DHCP, VPN, Tor | Aggressive: non-standard outbound ports are blocked until a rule is added |
| Privilege separation | Root password locked; `anjaruser` uses password-prompted `sudo` | `sudo bash` still grants a root shell — this is access control, not a sandbox |
| Mandatory access control | AppArmor enforced for shipped profiles | Debian's Chromium ships no base profile, so the Vault-deny snippet only engages if one is present; the LUKS volume is the real boundary |
| Data at rest | LUKS2 full-volume encryption for persistence (and optional full-disk on install) | Only as strong as the passphrase the user chooses |
| Anti-recovery | RAM lives in volatile memory; swap wiped at shutdown | Defeats casual recovery, **not** a cold-boot/hardware adversary — use Tails for true anonymity |
| Kernel hardening | `sysctl`: ptrace scope, kptr/dmesg restrict, rp_filter, syncookies, protected links | Standard hardening; not a substitute for a threat-modelled deployment |

Writing the limitations down is deliberate: overstating a security posture is
itself a security failure.

## 5. Reproducible build

The image is built with Debian `live-build`. The repository contains only
declarative configuration; no binary blobs:

- `auto/config` — live-build settings (distribution, architecture, bootloaders,
  persistence, build mode).
- `config/package-lists/*.list.chroot` — exactly which Debian packages enter the
  image, grouped by purpose (base, desktop, marketing, AI/content, security,
  installer).
- `config/hooks/normal/*.hook.chroot` — build-time steps run inside the image:
  user creation, security hardening, service wiring, image slimming.
- `config/includes.chroot/**` — files shipped verbatim into the OS (helper
  scripts, systemd units, desktop launchers, themed configs, Docker compose
  files for the marketing stack).
- `build_anjar.sh` — orchestrates `lb clean / lb config / lb build` and emits a
  flashable, checksummed ISO.

One command produces the image:

```bash
./build_anjar.sh                 # live + persistence + install-to-disk
./build_anjar.sh --no-installer  # slim live + persistence only
```

## 6. Two delivery modes

| Mode | What it is | Use case |
|---|---|---|
| **Live USB + persistence** | Boot from the stick; OS in RAM; data in a LUKS volume on the same stick | Portable, privacy-oriented, host untouched |
| **Install to disk** | Graphical Calamares installer writes Anjar OS permanently to an internal drive or another USB, with optional LUKS | A permanent personal machine |

The default build delivers **both in one ISO**: it boots live and offers an
"Install Anjar OS to Disk" action on the desktop.

## 7. Engineering quality measures taken

- Every shell script passes a non-interactive syntax check (`bash -n` / `sh -n`).
- Container/orchestration files validate as well-formed YAML.
- Build-time hooks are verified executable (live-build silently skips
  non-executable hooks — a common, hard-to-debug failure).
- Privilege-sensitive files (`sudoers` drop-ins) are written *inside* the image
  build as root, guaranteeing correct ownership and mode (0440), rather than
  copied from the source tree where ownership would be wrong.
- A documented changelog records each defect found and fixed across revisions
  (see `BUILD-AND-INSTALL.md`).

## 8. Limitations and future work

- **Install-to-disk** is the less battle-tested path and should be validated in a
  virtual machine before use on real hardware.
- **Twenty CRM** changes its container configuration frequently; its compose file
  may need refreshing against upstream documentation.
- A signed/Secure-Boot-compatible build and automated CI (build the ISO and
  smoke-test it in QEMU on every change) are natural next steps.

## 9. Repository map

```
anjar-os-build/
├── README.md                 project intro + quick start
├── BUILD-AND-INSTALL.md      full build / flash / install guide + changelog
├── PROJECT-OVERVIEW.md       this document
├── build_anjar.sh            master build script
├── auto/config               live-build configuration
└── config/
    ├── package-lists/        packages that enter the image
    ├── hooks/normal/          build-time customisation
    └── includes.chroot/       files shipped into the OS
```

---

*Anjar OS is a personal/educational project built on Debian GNU/Linux and other
free software. Debian is a trademark of Software in the Public Interest, Inc.;
this project is not affiliated with or endorsed by the Debian Project.*
