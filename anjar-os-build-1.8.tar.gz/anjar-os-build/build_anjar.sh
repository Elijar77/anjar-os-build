#!/bin/bash
# =============================================================================
#  Anjar OS — master build script
#  Default  : live + persistence + install-to-disk (Calamares)  -> one ISO
#  --no-installer : slim live + persistence only (smaller ISO)
#  Run on   : Debian 13 (Trixie) or Ubuntu 24.04+ as a normal user with sudo.
# =============================================================================
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE"

# --- 0. Parse mode ------------------------------------------------------------
INSTALLER=1
for a in "$@"; do
  case "$a" in
    --no-installer) INSTALLER=0 ;;
    --installer)    INSTALLER=1 ;;
    -h|--help) echo "Usage: $0 [--no-installer]"; exit 0 ;;
  esac
done
echo "ANJAR_INSTALLER=$INSTALLER" > ./.anjar-build.conf

if [ "$INSTALLER" = "1" ]; then
  MODE="live + persistence + install-to-disk (Calamares)"
  IMG="anjar-os-1.7-amd64"
else
  MODE="slim live + persistence (no installer)"
  IMG="anjar-os-1.7-live-amd64"
fi

echo "=================================================="
echo "  Anjar OS build — Debian 13 (Trixie)"
echo "  Mode: $MODE"
echo "=================================================="

# --- 0b. Toggle installer-only files ------------------------------------------
INST_LIST="config/package-lists/50-installer.list.chroot"
INST_LAUNCH="config/includes.chroot/etc/skel/Desktop/install-anjar.desktop"
if [ "$INSTALLER" = "1" ]; then
  [ -f "${INST_LIST}.off" ]   && mv "${INST_LIST}.off" "${INST_LIST}"     || true
  [ -f "${INST_LAUNCH}.off" ] && mv "${INST_LAUNCH}.off" "${INST_LAUNCH}" || true
else
  [ -f "${INST_LIST}" ]   && mv "${INST_LIST}" "${INST_LIST}.off"     || true
  [ -f "${INST_LAUNCH}" ] && mv "${INST_LAUNCH}" "${INST_LAUNCH}.off" || true
fi

# --- 1. Prerequisites (host tooling only; Calamares installs INTO the image) --
need=(live-build debootstrap squashfs-tools xorriso grub-pc-bin \
      grub-efi-amd64-bin mtools dosfstools)
miss=()
for p in "${need[@]}"; do dpkg -s "$p" >/dev/null 2>&1 || miss+=("$p"); done
if [ "${#miss[@]}" -gt 0 ]; then
  echo "Installing build deps: ${miss[*]}"
  sudo apt-get update
  sudo apt-get install -y "${miss[@]}"
fi

# --- 2. Disk space guard (need ~25GB) -----------------------------------------
free_kb=$(df --output=avail . | tail -1)
[ "$free_kb" -lt 26000000 ] && { echo "Need ~25GB free here. Abort."; exit 1; }

# --- 3. Clean previous build --------------------------------------------------
sudo lb clean --purge || true

# --- 4. Configure (no root needed; reads ./.anjar-build.conf for mode) ---------
echo "Applying live-build config..."
lb config

# --- 5. Build (root) ----------------------------------------------------------
echo "Building (45-90 min first run)..."
time sudo lb build

# --- 6. Result ----------------------------------------------------------------
ISO=$(ls -1 ${IMG}*.iso 2>/dev/null | head -1 || true)
if [ -n "$ISO" ]; then
  sha256sum "$ISO" | tee "${ISO}.sha256"
  echo
  echo "DONE -> $ISO"
  echo "Flash with:  sudo dd if=$ISO of=/dev/sdX bs=4M status=progress oflag=sync"
  echo "(replace /dev/sdX with your USB — double-check with lsblk!)"
  [ "$INSTALLER" = "1" ] && echo "This ISO boots LIVE *and* has 'Install Anjar OS to Disk' on the desktop."
else
  echo "Build finished but no ISO found — check the log above."
  exit 1
fi
