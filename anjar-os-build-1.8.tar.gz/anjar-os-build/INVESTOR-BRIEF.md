# Anjar OS — Investor Brief

**Prepared by:** _[your name]_ · **Date:** _[date]_ · **Stage:** working prototype (MVP)

> A note on this document's honesty: everything under "What works today" is real
> and demonstrable on a built USB. Everything under "Roadmap" is *not built yet*
> and is what investment would fund. Keeping that line clear is deliberate — it
> is what makes the working part credible.

---

## 1. One line

**Anjar OS is a private, offline "faceless content factory" on an encrypted USB
stick** — a bootable operating system that turns any laptop into a self-contained
studio for producing marketing content (copy, voiceover, faceless video) and
running the marketing back-office (CRM, email automation, analytics), with no
cloud dependency and no data leaving the device.

## 2. The problem

Solo creators, small marketing operators, and bilingual community marketers (e.g.
the UK Polish diaspora) juggle a dozen disconnected tools and cloud subscriptions,
hand their data and audience to third parties, and pay monthly for AI features
that stop working the moment they go offline or cancel. They want one place to go
from idea → finished post, that they own outright.

## 3. The product (what it is)

A single bootable USB image, built reproducibly from Debian Linux, containing:

- **Anjar AI Studio** — the centrepiece: an offline app that generates marketing
  copy (local LLM), turns scripts into voiceover, and assembles faceless videos
  (image + narration) — all on-device.
- **Marketing back-office** — Mautic (email/automation), Twenty (CRM), Metabase
  (analytics), provisioned into the encrypted volume on demand.
- **Creative tools** — GIMP, Inkscape, OBS, Kdenlive, plus local image generation
  (Fooocus).
- **Security spine** — LUKS encryption, hardened firewall, Tor/VPN, antivirus —
  the privacy guarantee that differentiates it.

## 4. What works today (demonstrable in a live demo)

| Capability | Status today |
|---|---|
| Reproducible OS build from source → flashable ISO | ✅ Builds with one script on Debian 13 |
| Boots as a portable, encrypted, hardened workstation | ✅ Live USB + LUKS persistence |
| Install permanently to disk (optional) | ✅ Graphical installer included |
| **Anjar AI Studio runs offline** | ✅ App runs locally; tested end-to-end |
| **One prompt → script + visual + voiceover + video** | ✅ Tested end-to-end, fully offline |
| **Faceless video assembly (image + voiceover → MP4)** | ✅ Verified producing real H.264/AAC video |
| Voiceover from text, out of the box | ✅ Offline TTS baked in |
| AI copywriting + image generation | ✅ After one-time on-device model install |
| Marketing stacks (Mautic/Twenty/Metabase) | ✅ One-click provision to encrypted USB |
| Bilingual EN/PL | ✅ Built into AI Studio |

**Suggested 5-minute demo:** boot the USB → unlock encrypted persistence → open
Anjar AI Studio → type a topic, generate a caption → paste a script, make a
voiceover → assemble a faceless video → show the finished MP4. Every step runs
with the network cable unplugged.

## 5. Why it's different

- **Offline + private by design.** Competing AI content tools are cloud SaaS that
  see all your data. Anjar runs on your encrypted stick; pull the cable and it
  still works. For privacy-conscious or compliance-sensitive users, that is the
  whole pitch.
- **All-in-one + owned.** Content creation *and* the marketing back-office in one
  place, owned outright — not a stack of monthly subscriptions.
- **Portable.** Boot any machine into your studio; leave no trace on the host.
- **Bilingual / community-first.** EN/PL from day one, aimed at an underserved
  diaspora-marketing niche the founder knows first-hand.

## 6. Honest current limitations (so there are no surprises)

- It is an **MVP built by one person**, not a polished commercial product.
- The **local AI model is small** (runs on modest hardware): great for drafts and
  demos, not yet agency-grade output.
- **Faceless video is basic** (single image + narration) at this stage.
- **No auto-publishing to social platforms** — by design. The tool produces
  ready-to-upload assets; actually posting needs the user's account
  credentials and carries platform-ban risk, so it stays a deliberate,
  user-controlled step (a secure credential vault is on the roadmap).
- **The install-to-disk path** should be validated in a VM before relying on it.
- The space is **competitive**; the moat is privacy/offline + integration +
  niche focus, not a unique algorithm.

## 7. Roadmap — what investment unlocks (not yet built)

1. **Better on-device AI** — larger/quantised models, fine-tuned for marketing
   copy in EN/PL; optional cloud "boost" when the user chooses.
2. **Richer faceless video** — multi-scene, captions/subtitles, B-roll, music,
   templated formats for TikTok/Shorts/Reels.
3. **Secure one-click publishing** — a credential vault (in the LUKS volume) and
   scheduled posting, done safely.
4. **Template & campaign library** — ready-made faceless formats and funnels.
5. **Polish, packaging, and support** — signed/Secure-Boot builds, auto-updates,
   onboarding, documentation, and a support channel.
6. **Distribution** — pre-loaded USB sticks, a paid "Pro" tier, and community
   partnerships in the target diaspora market.

## 8. The ask

_[State exactly what you are raising and for what — e.g. £X for N months to
deliver roadmap items 1–3 and a pre-loaded-USB pilot with M users. Leave the
numbers out until you and your investor agree them; do not invent traction or
projections you cannot defend.]_

## 9. The founder

_[2–3 honest lines: 18+ years in UK logistics, bilingual EN/PL, self-taught in
Linux/security/AI tooling, currently completing a cyber-security qualification,
and the person who actually built this OS from scratch. Your hands-on knowledge
of the trucker/diaspora niche is a genuine edge — say so.]_

---

*Anjar OS is built on Debian GNU/Linux and other free/open-source software.
Trademarks belong to their respective owners. This document describes a personal
project at prototype stage.*
