# Anjar OS — Secure Marketing & Defensive-Security Live USB

> **Brand colour:** Cardinal purple `#AF18A1` (deep `#7E1273`). Applied across the
> wallpaper, Anjar AI Studio, generated visuals, and the app icon.

Custom Debian **13 (Trixie)** live-USB. XFCE, encrypted LUKS persistence,
hardened defaults, marketing + faceless-content + defensive-security tooling,
and an **offline local AI agent** (Ollama).

## Design philosophy (read this first)
- **Anjar AI Studio — one prompt, done.** Type a single line and Anjar AI
  produces a script, a branded vertical visual, a voiceover, and a finished
  faceless MP4 — all offline, using only baked-in tools (no Fooocus needed for
  the visual). Also: an Ads tab (ad-copy variants + branded creative). AI copy
  and richer images upgrade after the one-time on-device model install.
- **Professional branded desktop** — custom Anjar wallpaper applied on first
  login; themed XFCE with desktop launchers for AI Studio and the marketing
  apps (Mautic / Twenty / Metabase).
- **Lightweight native tools are baked into the ISO** (XFCE, Chromium, OBS,
  Kdenlive, Audacity, GIMP/Inkscape, UFW, Tor, ClamAV, AppArmor, KeePassXC,
  BleachBit).
- **Heavy, stateful apps are provisioned into your encrypted USB on first use**
  — Mautic, Twenty CRM, Metabase (Docker), Fooocus + Ollama (Python/native).
  This keeps the ISO small (~3-4GB) and the heavy stuff updatable.

## Build it (on a Debian 13 / Ubuntu 24.04 machine, ~25GB free, 8GB RAM)
```bash
chmod +x build_anjar.sh
./build_anjar.sh                 # default: live + persistence + INSTALLER
#                                  -> anjar-os-1.7-amd64.iso
./build_anjar.sh --no-installer  # slim live + persistence only
#                                  -> anjar-os-1.7-live-amd64.iso
```
The default ISO boots as a **live USB with encrypted persistence** AND carries an
**"Install Anjar OS to Disk"** desktop icon (Calamares) so you can install it
permanently onto an internal drive or another USB, with optional LUKS.
Flash: `sudo dd if=anjar-os-1.7-amd64.iso of=/dev/sdX bs=4M status=progress oflag=sync`
(verify /dev/sdX with `lsblk` — wrong device = wiped disk).

## First boot
1. Auto-logs into XFCE as **anjaruser** (default password `anjar`, forced change).
2. Double-click **Anjar Control** on the desktop, then:
   - **persist**  → create LUKS-encrypted persistence on the USB
   - **webapps**  → Mautic / Twenty / Metabase
   - **ai**       → Fooocus + Ollama (local agent)
   - **agent**    → chat with your offline AI
   - **tor / vpn**→ route traffic
   - **veracrypt**→ hidden encrypted volumes

## Security posture (honest limits)
- UFW: inbound denied; outbound limited to DNS/HTTP/HTTPS/NTP/VPN/Tor.
- AppArmor enforced for profiles that ship with the system. The Chromium
  deny-snippet (blocks reading your Vault) only engages IF a base Chromium
  profile is present; Debian's chromium ships none by default, so treat the
  LUKS Vault itself — not AppArmor — as the real boundary for that data.
- RAM/swap wiped on shutdown (`sdmem`/`sdswap`) — defeats casual recovery,
  **not** a hardware/cold-boot forensic adversary. For true anonymity use Tails.
- root login locked; anjaruser has password-prompted sudo, not passwordless.

## What's NOT in the read-only image (by design)
Mautic, Twenty, Metabase, Fooocus models, Ollama models, VeraCrypt —
all live in your **encrypted persistence**, installed via Anjar Control.

## File map
- `auto/config` ............ live-build settings (Trixie, hybrid ISO)
- `config/package-lists/` .. what gets installed into the image
- `config/hooks/normal/` ... build-time: user, hardening, services, cleanup
- `config/includes.chroot/`. files shipped into the OS (scripts, units, configs)
- `build_anjar.sh` ......... master build script
